package com.example.demo.service;

import com.example.demo.collection.Reservation;

public interface ReservationService {
    String create(Reservation reservation);
}
